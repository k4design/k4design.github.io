APERTURE GLOBAL
Marketing Strategy — Parque das Nações, Lisbon, Portugal
Prepared September 2026

------------------------------------------------------------
TO VIEW
------------------------------------------------------------

Double-click:

    Aperture Campaign Strategy - Parque das Nacoes.dc.html

It opens in any web browser. No internet connection is
required — fonts, images and page runtime are all included
in this folder.

A print-ready PDF of the same document is also included:

    Aperture Campaign Strategy - Parque das Nacoes.pdf

------------------------------------------------------------
NOTES
------------------------------------------------------------

- 8 pages, US Letter (8.5 x 11 in).
- Keep the files together. The .html needs the assets/,
  fonts/ and .js files in this folder to display correctly.
- This document describes a planned campaign. The campaign
  has not yet launched, and it contains no performance data.
